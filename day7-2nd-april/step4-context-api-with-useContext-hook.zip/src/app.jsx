import GrandComp from "./components/grandcomp";

const App = () => {
    return <div style={ {border : "2px solid red", padding : "10px"} }>
                <h2>Context API</h2>
                <GrandComp/>
           </div>
}

export default App;