import { createContext } from "react";
const FamilyContext = createContext();

export { FamilyContext }