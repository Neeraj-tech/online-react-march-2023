import axios from "axios";
import { useEffect, useState } from "react";

let App = ()=> {
    let [users, setUsers] = useState([]);
    let [show, toggleShow] = useState(true);
    let [user, setUser] = useState({ title : "", firstname : "", lastname : "", power : "", city : "" });
    let [euser, setEditUser] = useState({ title : "", firstname : "", lastname : "", power : "", city : "" });

    useEffect(()=>{
        refresh();
    },[]);

    let refresh = ()=>{
        axios.get("http://localhost:5050/data")
        .then(res => setUsers(res.data))
        .catch(error => console.log("Error ", error ));
    }
    let userHandler = (evt)=>{
        setUser({...user, [evt.target.id] : evt.target.value });
    };
    let storeEditInfoHandler = (evt)=>{
        setEditUser({...euser, [evt.target.id] : evt.target.value });
    };

    let addUser = ()=>{
        axios.post("http://localhost:5050/data", user )
        .then(res => {
            console.log( res.data.message );
            refresh();
            setUser({ title : "", firstname : "", lastname : "", power : "", city : "" })
        })
        .catch(error => console.log("Error ", error.error ));
    }

    let editUserHandler = (uid)=>{
        // alert("are you sure to edit this user's info "+ uid );
        axios.get("http://localhost:5050/update/"+uid)
        .then(res => {
            setEditUser(res.data)
            toggleShow(false)
        })
        .catch(err => console.log(err.error))
    }

    let updateSelectedUserInfo = (uid)=> {
        axios.post("http://localhost:5050/update/"+uid, euser)
        .then(res => {
            console.log(res.data.message);
            refresh();
            toggleShow(true)
        })
        .catch(err => console.log(err))
    }
    let deleteHandler = (uid)=>{
        axios.delete("http://localhost:5050/delete/"+uid)
        .then( res => { 
            console.log( res.data.message );
            refresh();
        })
        .catch(err => {
            console.log(err)
        })
    }
    return <div className="container">
                <h1>Users MongoDB App</h1>
                {/* <p>{ JSON.stringify(users) }</p> */}
                { show && <div>
                    <h1>Create A New User</h1>
                <div className="mb-3">
                    <label htmlFor="title" className="form-label">User Title</label>
                    <input onChange={(evt)=> userHandler(evt)} value={user.title} className="form-control" id="title"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="firstname" className="form-label">User First Name</label>
                    <input onChange={(evt)=> userHandler(evt)} value={user.firstname} className="form-control" id="firstname"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="lastname" className="form-label">User Last Name</label>
                    <input onChange={(evt)=> userHandler(evt)} value={user.lastname} className="form-control" id="lastname"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="city" className="form-label">User City</label>
                    <input onChange={(evt)=> userHandler(evt)} value={user.city} className="form-control" id="city"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="power" className="form-label">User Power</label>
                    <input onChange={(evt)=> userHandler(evt)} value={user.power} type="range" min={0} max={10} step={1} className="form-control" id="power"/>
                </div>
                <button onClick={ addUser } type="submit" className="btn btn-primary">Add New User</button>
                
                </div>}
                { !show && <div>
                    <hr />

                <h1>Edit The Selected User</h1>
                <div className="mb-3">
                    <label htmlFor="title" className="form-label">Edit User Title</label>
                    <input onChange={(evt)=> storeEditInfoHandler(evt)} value={euser.title} className="form-control" id="title"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="firstname" className="form-label">Edit User First Name</label>
                    <input onChange={(evt)=> storeEditInfoHandler(evt)} value={euser.firstname} className="form-control" id="firstname"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="lastname" className="form-label">Edit User Last Name</label>
                    <input onChange={(evt)=> storeEditInfoHandler(evt)} value={euser.lastname} className="form-control" id="lastname"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="city" className="form-label">Edit User City</label>
                    <input onChange={(evt)=> storeEditInfoHandler(evt)} value={euser.city} className="form-control" id="city"/>
                </div>
                <div className="mb-3">
                    <label htmlFor="power" className="form-label">Edit User Power</label>
                    <input onChange={(evt)=> storeEditInfoHandler(evt)} value={euser.power} type="range" min={0} max={10} step={1} className="form-control" id="power"/>
                </div>
                <button type="submit" onClick={ ()=> updateSelectedUserInfo(euser._id) } className="btn btn-primary">Edit User Info </button>
                </div>}
                <hr />
                { users.length > 0 && <div>
                    <h1>Users List</h1>
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>City</th>
                                <th>Power</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                users.map( (hero, idx) => {
                                    return <tr key={ idx }>
                                                <td>{ hero.title }</td>
                                                <td>{ hero.firstname }</td>
                                                <td>{ hero.lastname }</td>
                                                <td>{ hero.city }</td>
                                                <td>{ hero.power }</td>
                                                <td>
                                                    <button onClick={ ()=> editUserHandler(hero._id) } className="btn btn-warning">Edit</button>
                                                </td>
                                                <td>
                                                    <button onClick={ ()=> deleteHandler(hero._id)} className="btn btn-danger">Delete</button>
                                                </td>
                                            </tr>
                                })
                            }
                        </tbody>
                    </table>
                </div>}
           </div>
}

export default App;