// lets load all dependencies
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const config = require("./config.json");

let app = express();
//-----------------------------------
app.use(cors());
app.use(express.json());
//-----------------------------------
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let User = mongoose.model("User",Schema({
    id : ObjectId,
    title : String,
    firstname : String,
    lastname : String,
    power : String,
    city : String
}));
const url = config.url.replace("{{user}}", config.user)
.replace("{{password}}", config.password)
.replace("{{dbname}}", config.dbname)
.replace("{{clusterName}}", config.clusterName)
.replace("{{dbstring}}", config.dbstring);

mongoose.connect(url)
.then(res=>console.log("DB Connected"))
.catch(error=>console.log("Error ", error));
//-----------------------------------
// ROUTES
// create
app.post("/data", function(req, res){
    let user = new User(req.body);
    user.save()
    .then(dbres => res.status(200).send({"message" : dbres.title+" was added to the database"}) )
    .catch(err => {
        console.log("Error ", err);
        res.status(400).send({ "error" : "error adding user" })
    });
});

// read
app.get("/data", function(req, res){
    User.find()
    .then(dbres => res.status(200).send(dbres))
    .catch(err => {
        console.log("Error Fetching Records", err);
        res.status(400).send({ "error" : "error finding users" })
    })
});

// read before update
app.get("/update/:id", function(req, res){
    User.findByIdAndUpdate({ _id : req.params.id })
    .then( dbres => res.status(200).send(dbres) )
    .catch(err => {
        console.log("Error Fetching Records", err);
        res.status(400).send({ "error" : "error finding user" })
    }); 
});

// update
app.post("/update/:id", function(req, res){
    User.findByIdAndUpdate({ _id : req.params.id })
    .then( dbres => {
        let user = new User(dbres);
        user.title = req.body.title;
        user.firstname = req.body.firstname;
        user.lastname = req.body.lastname;
        user.power = req.body.power;
        user.city = req.body.city; 
        user.save()
        .then(updatedinfo => res.status(200).send({"message" : updatedinfo.title+" was updated in the database"}) )
        .catch(error => res.status(400).send({"error" : "info was not updated"}) )
        /* 
        if( dbres._id === req.body._id ){
            let user = new User(req.body);
            user.save()
            .then(updatedinfo => {
                res.status(200).send({"message" : updatedinfo.title+" was updated in the database"}) 
            })
            .catch(error => console.log("Error ", error))
        }else{
            console.log("Error : User data mismatch")
        } 
        */
    })
    .catch(err => {
        console.log("Error Fetching Records", err);
        res.status(400).send({ "error" : "error finding user" })
    }); 
});

// delete
app.delete("/delete/:id", function(req, res){
    User.findByIdAndDelete({ _id : req.params.id })
    .then( dbres => res.status(200).send({ message : dbres.title+" was deleted " }))
    .catch(err => {
        console.log("Error ", err);
        res.status(400).send({"error" : "error deleting user"});
    })
});

app.listen(config.port,config.host,function(error){
    if(error){ console.log("Error ", error )}
    else{ console.log(`Express is now running on ${config.host}:${config.port}`) }
})