import { Component } from "react";
import ChildComponent from "./child";

class App extends Component{
    render(){
        return <div>
            <h2>App Component</h2>
            <ChildComponent title="First Child Component" version={101} power={5} />
            <ChildComponent title="Second Child Component" version={202} power={10} />
            <ChildComponent title="Third Child Component" version={303} power={15} />
            <hr />
            <ChildComponent title="Fourth Child Component" version={404} power={20} />
            <ChildComponent title="Fifth Child Component" version={505} power={25} />
            <ChildComponent title="Sixth Child Component" version={606} power={30}/>
            <ChildComponent title="Seventh Child Component" version={707} power={35} />
        </div>
    }
};

export default App;