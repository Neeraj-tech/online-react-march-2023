import { Component } from "react";
import PropTypes from 'prop-types';

class ChildComponent extends Component{
    /* 
    static defaultProps = {
        title : "Default Title in Child Component",
        version : 0,
        power : 1
    } 
    */
   static propTypes = {
    title : PropTypes.string.isRequired,
    version : PropTypes.number.isRequired,
    power : PropTypes.number.isRequired,
   }
    render(){
        return <div style={ {border : "2px solid red", padding : "10px", margin : "10px"} }>
                    <h2>Child Component</h2>
                    <h3>title is : { this.props.title.toUpperCase() }</h3>
                    <h3>version is : { this.props.version }</h3>
                    <h3>power is : { this.props.power }</h3>
               </div>
    }
};
/* 
ChildComponent.defaultProps = {
        title : "Default Title in Child Component",
        version : 0,
        power : 1
} */
export default ChildComponent;