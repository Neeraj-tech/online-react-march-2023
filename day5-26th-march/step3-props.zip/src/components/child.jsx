import { Component } from "react";

class ChildComponent extends Component{
    // title = this.props.title;
    render(){
    // let props = this.props;
    let { children, title, version } = this.props;
        return <div>
                    <h2>Child Component</h2>
                    {/* <h3>{ this.title }</h3> */}
                    <h3>{ title }</h3>
                    <h3>Version { version + 2 }</h3>
                   <div style={ {border : "2px solid red"} }>
                   { children }
                   </div>
               </div>
    }
};

export default ChildComponent;