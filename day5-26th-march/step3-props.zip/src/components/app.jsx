import { Component } from "react";
import ChildComponent from "./child";

class App extends Component{
    render(){
        return <div>
            <h2>App Component</h2>
            <ChildComponent version={101} title="First Child">
                <ul>
                    <li>List ITem </li>
                    <li>List ITem </li>
                    <li>List ITem </li>
                    <li>List ITem </li>
                    <li>List ITem </li>
                </ul>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita impedit, cum repellendus neque deserunt dolore accusantium distinctio at hic voluptas autem excepturi consequatur mollitia perspiciatis alias ad possimus blanditiis ipsam.
                </p>
            </ChildComponent>
            <ChildComponent version={201} title="Second Child"/>
            <ChildComponent version="301" title="Second Child"/>
        </div>
    }
};

export default App;