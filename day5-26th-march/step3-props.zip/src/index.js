import React from "react";
import ReactDOM from "react-dom/client";
import App from "./components/app";

ReactDOM
.createRoot(document.getElementsByClassName("root")[0])
.render(<div>  <h1>Props</h1> <App/> </div>)