import { screen, render, getByText, fireEvent } from "@testing-library/react";
import App from "./App";


describe("this is to test the App Component", function(){
  /*  
  let app = null;
  beforeAll(function(){
    app = render(<App/>);
  });

  beforeEach(function(){
    console.log("before each was logged")
  });

  it("checking if the app is defined", function(){
    expect(app).toBeDefined()
  }); 
  */

  it("checking for message property displayed on app", function(){
    // const message = app.getByText(/welcome to your life/i);
    // expect(message).toBeInTheDocument();
    // console.log(app.getByText("welcome to your life"))

    let { getByText } = render(<App/>);
    let messageElement = getByText("welcome to your life");
    expect(messageElement).toBeInTheDocument();
  });

  it("checking for power property displayed on app", function(){
    let { getByText } = render(<App/>);
    let powerElement = getByText("Power : 0");
    expect(powerElement).toBeInTheDocument();
  });

  it("checking for button with label Increase Power on app", function(){
    let { getByText } = render(<App/>);
    let buttonElement = getByText("Increase Power");
    expect(buttonElement).toBeInTheDocument();
  });

  it("checking h1 to have the text Power : 1", function(){
     let { getByText } = render(<App/>);
     let powerElement = getByText("Power : 0");
     let buttonElement = getByText("Increase Power");
     fireEvent.click(buttonElement);
     fireEvent.click(buttonElement);
     expect(powerElement.textContent).toBe("Power : 2");
  });

})