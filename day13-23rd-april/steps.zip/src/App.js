import { useState } from 'react';
import './App.css';

function App() {
  let [message, setMessage] = useState("welcome to your life");
  let [power, setPower] = useState(0);

  let increasePower = ()=>{
    setPower(power + 1);
  }
  
  return ( 
    <div className="App">
       <div>{ message }</div>
       <h1>Power : { power }</h1>
       <button onClick={ increasePower }>Increase Power</button>
    </div>
  );
}

export default App;
