import { Outlet } from "react-router-dom";

let WonderWomenComp = ()=>{
    return <div>
                <h2>WonderWomen Component</h2>
                <div style={ {border : "2px solid red"} }>
                    <Outlet/>
                </div>
            </div>
};
export default WonderWomenComp