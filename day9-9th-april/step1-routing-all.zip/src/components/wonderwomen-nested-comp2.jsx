let WonderWomenCompNestedComp2 = ()=>{
    return <div>
                <h2>WonderWomen Nested Component 2</h2>
            </div>
};
export default WonderWomenCompNestedComp2