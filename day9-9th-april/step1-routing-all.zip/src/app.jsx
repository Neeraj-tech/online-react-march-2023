import { BrowserRouter, Link, NavLink, Route, Routes } from "react-router-dom";
import HomeComp from "./components/home";

/* 
import BatmanComp from "./components/batman";
import AquamanComp from "./components/aquaman";
import SupermanComp from "./components/superman";
import WonderWomenComp from "./components/wonderwomen";
import NotFoundComp from "./components/notfound";
import WonderWomenCompNestedComp1 from "./components/wonderwomen-nested-comp1";
import WonderWomenCompNestedComp2 from "./components/wonderwomen-nested-comp2"; 
*/

import "./linkstyle.css";
import React, { Suspense, useState } from "react";
let App = ()=> {
    let [power,managePower] = useState(25);
    let BatmanComp = React.lazy( ()=> import("./components/batman") );
    let AquamanComp = React.lazy( ()=> import("./components/aquaman") );
    let SupermanComp = React.lazy( ()=> import("./components/superman") );
    let WonderWomenComp = React.lazy( ()=> import("./components/wonderwomen") );
    let NotFoundComp = React.lazy( ()=> import("./components/notfound") );
    let WonderWomenCompNestedComp1 = React.lazy( ()=> import("./components/wonderwomen-nested-comp1") );
    let WonderWomenCompNestedComp2 = React.lazy( ()=> import("./components/wonderwomen-nested-comp2") );
    return <div className="container"> 
                <h1>Using Routes</h1> 
                <h2>Power is { power }</h2>
                <input type="range" value={power} onInput={ (evt)=> managePower(evt.target.value) } />
                <BrowserRouter>
                    {/* all our router configurations come here */}
                    {/* <ul>
                        <li> <a href="/">Home</a> </li>
                        <li> <a href="/about">About</a> </li>
                        <li> <a href="/product">Product</a> </li>
                        <li> <a href="/contact">Contact</a> </li>
                    </ul> */}
                    {/* <ul>
                        <li> <Link to="/">Home</Link> </li>
                        <li> <Link to="/batman">Batman</Link> </li>
                        <li> <Link to="/superman">Superman</Link> </li>
                        <li> <Link to="/aquaman">Aquaman</Link> </li>
                        <li> <Link to="/wonderwomen">Wonder Women</Link> 
                            <ul>
                                <li> <Link to="/wonderwomen/movie1">Movie 1</Link> </li>
                                <li> <Link to="/wonderwomen/movie2">Movie 2</Link> </li>
                            </ul>
                        </li>
                        <li> <Link to="/flash">Flash</Link> </li>
                        <li> <Link to="/cyborg">Cyborg</Link> </li>
                    </ul> */}
                    <ul>
                        <li> <NavLink className={ ({ isActive })=> isActive ? 'boxer' : '' } to="/">Home</NavLink> </li>
                        <li> <NavLink className={ ({ isActive })=> isActive ? 'boxer' : '' } to="/batman">Batman</NavLink> </li>
                        <li> <NavLink className={ ({ isActive })=> isActive ? 'boxer' : '' } to={'/superman/'+power }>Superman</NavLink> </li>
                        <li> <NavLink className={ ({ isActive })=> isActive ? 'boxer' : '' } to="/aquaman">Aquaman</NavLink> </li>
                        <li> <NavLink className={ ({ isActive })=> isActive ? 'boxer' : '' } to="/wonderwomen">Wonder Women</NavLink> 
                            <ul>
                                <li> <NavLink className={ ({ isActive })=> isActive ? 'boxer' : '' } to="/wonderwomen/movie1">Movie 1</NavLink> </li>
                                <li> <NavLink className={ ({ isActive })=> isActive ? 'boxer' : '' } to="/wonderwomen/movie2">Movie 2</NavLink> </li>
                            </ul>
                        </li>
                        <li> <NavLink className={ ({ isActive })=> isActive ? 'boxer' : '' } to="/flash">Flash</NavLink> </li>
                        <li> <NavLink className={ ({ isActive })=> isActive ? 'boxer' : '' } to="/cyborg">Cyborg</NavLink> </li>
                    </ul>
                    <Routes>
                        <Route path="/" element={ <HomeComp/> } />
                        <Route path="/batman" element={ <Suspense fallback={ <> ... loading </> }> <BatmanComp/>  </Suspense> } />
                        <Route path="/superman/:arg1" element={ <Suspense fallback={ <> ... loading </> }> <SupermanComp/>  </Suspense> } />
                        <Route path="/aquaman" element={ <Suspense fallback={ <> ... loading </> }> <AquamanComp/>  </Suspense>  } />
                        <Route path="/wonderwomen" element={ <Suspense fallback={ <> ... loading </> }> <WonderWomenComp/>  </Suspense>  }>
                            <Route path="movie1" element={ <Suspense fallback={ <> ... loading </> }> <WonderWomenCompNestedComp1/>  </Suspense>  }/>
                            <Route path="movie2" element={ <Suspense fallback={ <> ... loading </> }> <WonderWomenCompNestedComp2/>  </Suspense> }/>
                        </Route>
                        <Route path="/flash" element={ <Suspense fallback={ <> ... loading </> }> <BatmanComp/>  </Suspense> } />
                        <Route path="*" element={ <Suspense fallback={ <> ... loading </> }> <NotFoundComp/>  </Suspense> } />
                    </Routes>
                </BrowserRouter>
           </div>

}

export default App;

