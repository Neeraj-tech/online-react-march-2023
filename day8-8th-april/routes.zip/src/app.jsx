import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import HomeComp from "./components/home";
import BatmanComp from "./components/batman";
import AquamanComp from "./components/aquaman";
import SupermanComp from "./components/superman";
import WonderWomenComp from "./components/wonderwomen";
import NotFoundComp from "./components/notfound";
let App = ()=> {
    
    return <div className="container"> 
                    <h1>Using Routes</h1> 
                <BrowserRouter>
                    {/* all our router configurations come here */}
                    {/* <ul>
                        <li> <a href="/">Home</a> </li>
                        <li> <a href="/about">About</a> </li>
                        <li> <a href="/product">Product</a> </li>
                        <li> <a href="/contact">Contact</a> </li>
                    </ul> */}
                    <ul>
                        <li> <Link to="/">Home</Link> </li>
                        <li> <Link to="/batman">Batman</Link> </li>
                        <li> <Link to="/superman">Superman</Link> </li>
                        <li> <Link to="/aquaman">Aquaman</Link> </li>
                        <li> <Link to="/wonderwomen">Wonder Women</Link> </li>
                        <li> <Link to="/flash">Flash</Link> </li>
                        <li> <Link to="/cyborg">Cyborg</Link> </li>
                    </ul>
                    <Routes>
                        <Route path="/" element={ <HomeComp/> } />
                        <Route path="/batman" element={ <BatmanComp/> } />
                        <Route path="/superman" element={ <SupermanComp/> } />
                        <Route path="/aquaman" element={ <AquamanComp/>} />
                        <Route path="/wonderwomen" element={ <WonderWomenComp/>} />
                        <Route path="*" element={ <NotFoundComp/>} />
                    </Routes>
                </BrowserRouter>
           </div>

}

export default App;

