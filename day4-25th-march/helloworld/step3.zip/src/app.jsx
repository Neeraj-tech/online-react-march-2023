/* 
let App = function(){
    return <h1>Welcome to your life</h1>
};

export default App; 
*/

import { Component } from "react";

class App extends Component{
    title = "React Online Training";
    render(){
        return <div>
                    <h1>{ this.title }</h1>
                    <h1>{ this.title.toUpperCase() }</h1>
                    <h1>{ this.title.toLowerCase() }</h1>
               </div>
    }
};

export default App;