import NestedElm from "./nestedElm";
let Elm = function(){
    let messages = ["item 1", "item 2", "item 3", "item 4"];
    return <ul>{
            messages.map((val, idx)=><NestedElm key={ idx } title="hello" message={val}/>)
        }</ul>
}
export default Elm;