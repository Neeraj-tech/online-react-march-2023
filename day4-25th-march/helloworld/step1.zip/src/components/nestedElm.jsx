let NestedElm = function(props){
    // let message = "Hello";
    return <li>{ props.message || "default message" } Title is { props.title }</li>
};
export default NestedElm