const redux = require("redux");
const thunkMiddleware = require("redux-thunk").default;
const axios = require("axios");
// ----------------------------------------------------
const createStore = redux.legacy_createStore;
const applyMiddleware = redux.applyMiddleware;

// action type ( intention )
const AXIOS_USER_REQUEST = "AXIOS_USER_REQUEST";
const AXIOS_USER_SUCCESS = "AXIOS_USER_SUCCESS";
const AXIOS_USER_ERROR = "AXIOS_USER_ERROR";

// action object creator ( function that creates action object )
const fetchUsers = ()=>{
    return {
        type : AXIOS_USER_REQUEST
    }
}
const fetchUsersSuccess = (users)=>{
    return {
        type : AXIOS_USER_SUCCESS,
        payload : users
    }
}
const fetchUsersError = (error)=>{
    return {
        type : AXIOS_USER_ERROR,
        payload : error
    }
}
// default state object 
const intialState = {
    loading : false,
    users : [],
    error : ''
}
// reducer 
const reducer = (state = intialState, action)=>{
    switch(action.type){
        case AXIOS_USER_REQUEST : return {
            ...state,
            loading : true
        }
        case AXIOS_USER_SUCCESS : return {
            ...state,
            loading : false,
            users : action.payload
        }
        case AXIOS_USER_ERROR : return {
            ...state,
            loading : false,
            error : action.payload
        }
        default : return state
    }
}
// thunk actions
const thunkFetchUsers = ()=>{
    return function(dispatch){
        dispatch( fetchUsers() )
    }
}
const thunkAjaxFetchUsersResponse = ()=>{
    return function(dispatch){
        axios.get("https://reqres.in/vijay/vijay?page=3")
        .then( res => dispatch( fetchUsersSuccess( res.data.data ) ))
        .catch( error => dispatch( fetchUsersError( error.response.statusText ) ) )
    }
}

// store 
const store = createStore(reducer, applyMiddleware( thunkMiddleware ));
console.log( store.getState() );
console.log("********* subscribed  ********* ");
// subscribe
store.subscribe(()=>{
    console.log( store.getState() );
})
    // dispatch
store.dispatch( thunkFetchUsers() );
store.dispatch( thunkAjaxFetchUsersResponse() );
/* setTimeout(function(){
},1000) */