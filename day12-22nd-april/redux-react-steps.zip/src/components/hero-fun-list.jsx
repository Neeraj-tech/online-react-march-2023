import { useDispatch, useSelector } from "react-redux";
import { addHero } from "../redux";

let HeroFunList = ()=> {
    
    const numberOfHeroes = useSelector( state => state.numberOfHeroes );
    const dispatch = useDispatch();

        return <div>
                    <h2>Redux with Hook Component</h2>
                    <fieldset>
                        <legend>Hero's Infomation</legend>
                        <h3>Number Of Heroes : { numberOfHeroes } </h3>
                        <button onClick={ ()=> dispatch( addHero() ) }>Add Hero</button>
                    </fieldset>
               </div>
};

export default HeroFunList;