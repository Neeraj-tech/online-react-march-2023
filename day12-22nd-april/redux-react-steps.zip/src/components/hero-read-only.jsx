import { Component } from "react";
import { connect } from "react-redux"; 


// bind the prop of this component to state of redux
const mapStateToProps = (state)=>{
    return {
        numberOfHeroes : state.numberOfHeroes
    }
}

class HeroReadOnlyClassList extends Component{
    render(){
        return <div>
                    <h2>Redux with Readonly Class Component</h2>
                    <fieldset>
                        <legend>Hero's Infomation</legend>
                        <h3>Number Of Heroes : { this.props.numberOfHeroes } </h3>
                    </fieldset>
               </div>
    }
};

export default connect(mapStateToProps)(HeroReadOnlyClassList);