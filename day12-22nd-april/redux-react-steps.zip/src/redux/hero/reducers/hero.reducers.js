import { ADD_HERO } from "../types/hero.type";

const intialState = {
    numberOfHeroes : 1
};

const heroReducer = (state = intialState, action)=>{
    switch(action.type){
        case ADD_HERO : return {...state, numberOfHeroes : state.numberOfHeroes + 1 }
        default : return state
    }
};

export default heroReducer