import { Provider } from "react-redux";
import HeroClassList from "./components/herolist";
import HeroReadOnlyClassList from "./components/hero-read-only";
import store from "./redux/store";
import HeroFunList from "./components/hero-fun-list";

const App = ()=>{
    return <div>
                <h1>React Redux</h1>
                <Provider store={ store }>
                    <HeroClassList/>
                    <HeroReadOnlyClassList/>
                    <HeroFunList/>
                </Provider>
           </div>
}

export default App;